function sendMessage() {

  const name = document.getElementById("name").value;

  alert("Thank you, " + name + "! Your message has been sent successfully.");

  return false; // Prevent actual form submission

}